//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Ms65xhTs.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-AuUZaJMp.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-BoYPEune.js",
			"/assets/link-BeovRVag.js",
			"/assets/useNavigate-TvlAWmtA.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-AuUZaJMp.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-SAVPt5EW.js",
			"/assets/client-cLw6edTc.js",
			"/assets/theme-toggle-PmI1CmaU.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DMFjjq_u.js",
			"/assets/client-cLw6edTc.js",
			"/assets/theme-toggle-PmI1CmaU.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
