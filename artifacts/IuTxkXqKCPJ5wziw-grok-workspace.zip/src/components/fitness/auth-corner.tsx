import { Link } from "@tanstack/react-router";
import { useState, useSyncExternalStore } from "react";
import { authEnabled, signOut } from "@/lib/auth/client";
import { hasGateSessionMarker } from "@/lib/auth/gate-session-marker";
import { useCurrentUser, useCurrentUserState } from "@/lib/auth/use-current-user";

const subscribeToNothing = () => () => {};
const noGateSessionOnServer = () => false;

export function AuthCorner() {
  const { user, isPending } = useCurrentUserState();
  if (!authEnabled) return null;
  if (isPending || !user) {
    return (
      <span className="inline-flex h-8 w-[4.75rem] items-center justify-end">
        {isPending ? (
          <span className="inline-block h-8 w-full animate-pulse rounded-full bg-track" />
        ) : (
          <Link to="/login" className="capsule-quiet inline-flex h-8 items-center px-3 text-[10px]">
            Sign in
          </Link>
        )}
      </span>
    );
  }
  return <SignedChip />;
}

function SignedChip() {
  const user = useCurrentUser();
  const [signingOut, setSigningOut] = useState(false);
  const gateSession = useSyncExternalStore(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
  if (!user) return null;
  const label = user.displayName ?? user.primaryEmail ?? "You";
  return (
    <span className="inline-flex h-8 items-center gap-1.5">
      <span
        className="grid size-8 place-items-center rounded-full bg-navy text-xs font-bold text-on-navy"
        title={label}
      >
        {label.charAt(0).toUpperCase()}
      </span>
      {authEnabled && !gateSession ? (
        <button
          type="button"
          disabled={signingOut}
          onClick={() => {
            setSigningOut(true);
            void signOut().catch(() => setSigningOut(false));
          }}
          className="text-[10px] font-semibold tracking-[0.14em] text-muted uppercase disabled:opacity-60"
        >
          {signingOut ? "…" : "Out"}
        </button>
      ) : null}
    </span>
  );
}
